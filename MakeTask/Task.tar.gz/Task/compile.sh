 #!/bin/bash
echo "Compilation Starts"
rm -rf TaskBin
make all
echo "Compilation Ends"
